import os
import random

def randomly_select_lines(folder_path, num_lines):
    selected_lines = []

    # Get a list of all text files in the specified folder
    txt_files = [file for file in os.listdir(folder_path) if file.endswith(".txt")]

    # Check if there are any text files in the folder
    if not txt_files:
        print("No text files found in the specified folder.")
        return selected_lines

    # Iterate through each text file
    for txt_file in txt_files:
        file_path = os.path.join(folder_path, txt_file)

        # Read the lines from the text file
        with open(file_path, 'r', encoding='ISO-8859-1' ) as file:  #, encoding='utf-8'
            lines = file.readlines()

            # Randomly select lines from the file
            selected_lines.extend(random.sample(lines, min(num_lines, len(lines))))

    return selected_lines

# Specify the folder path and the number of lines to randomly select
folder_path = "/mnt/d/github/user_story/7zbk8zsd8y-1"
num_lines_to_select = 100

# Call the function to get the randomly selected lines
random_lines = randomly_select_lines(folder_path, num_lines_to_select)

# Print the randomly selected lines
for line in random_lines:
    print(line.strip())
